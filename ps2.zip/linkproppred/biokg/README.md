# ogbl-biokg

This code includes implementation of TransE, DistMult, ComplEx and RotatE with OGB evaluator. It is based on this [repository](https://github.com/DeepGraphLearning/KnowledgeGraphEmbedding).

## Training & Evaluation

```
# Run with default config
bash examples.sh
```